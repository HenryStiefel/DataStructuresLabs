#include "Product.h"
using namespace std;

Product::Product()
{
	myID = 0;
	myUnits = 0;
	myPrices = 0.0;
	mySales = 0.0;
	myDescription = "";
	isTaxExempt = false;
}

void Product::setID(int id) { myID = id; }
void Product::setUnits(int units) { myUnits = units; }
void Product::setPrices(double prices) { myPrices = prices; }
void Product::setSales(double sales) { mySales = sales; }
void Product::setDescription(string description) { myDescription = description; }
void Product::setTaxExempt(int exemption) {
	if (exemption == 1)
	{
		isTaxExempt = true;
	}
}