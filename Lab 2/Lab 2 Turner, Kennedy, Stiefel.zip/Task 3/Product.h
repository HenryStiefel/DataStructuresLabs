#pragma once
#include <string>
using namespace std;

#ifndef PRODUCT_H
#define PRODUCT_H

class Product
{
private:
	int myID, myUnits;
	double myPrices, mySales;
	string myDescription;
	bool isTaxExempt;
public:
	Product();
	void setID(int);
	void setUnits(int);
	void setPrices(double);
	void setSales(double);
	void setDescription(string);
	void setTaxExempt(int);

	int getID() const { return myID; }
	int getUnits() const { return myUnits; }
	double getPrices() const { return myPrices; }
	double getSales() const { return mySales; }
	string getDescription() const { return myDescription; }
	bool getTaxExempt() const { return isTaxExempt; }
};
#endif

