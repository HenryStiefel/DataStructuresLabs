// This program produces a sales report for DLC, Inc.
#include <iostream>
#include <iomanip>
#include "Product.h"
#include <fstream>
using namespace std;

// Function prototypes
void calcSales(Product[]);
void showOrder(Product[]);
void dualSort(Product[]);
void showTotals(Product[]);
int initializeProducts(Product[]);

// NUM_PRODS is the number of products produced.
const int NUM_PRODS = 9;

int main()
{
	Product products[NUM_PRODS];
	
	//case where file input is correct and opens successfully
	if (initializeProducts(products) == 1) 
	{
		// Calculate each product's sales.
		calcSales(products);

		// Sort the elements in the sales array in descending
		// order and shuffle the ID numbers in the id array to
		// keep them in parallel.
		dualSort(products);

		// Set the numeric output formatting.
		cout << setprecision(2) << fixed << showpoint;

		// Display the products and sales amounts.
		showOrder(products);

		// Display total units sold and total sales.
		showTotals(products);
	}

	// case where there are too many or too few input lines	
	else if (initializeProducts(products) == 2) 
	{
		cout << "File error. Either not enough or too many lines of input." << endl;
	}

	else //case where there is no existing file 
	{
		cout << "File error. Input data is incorrect." << endl;
	}

	return 0;
}

int initializeProducts(Product prod[])
{
	fstream infile;
	string fileName;

	cout << "Enter the name of the file to use (include \".txt\") \n(items.txt, morelines.txt, lesslines.txt, emptyfile.txt)) " << endl;
	cin >> fileName;
	infile.open(fileName);
	int lineNum = 1;
	int prodNum = 0;
	string line;

	if (!infile)
	{
		return 0;
	}

	else
	{
		int lineCount = 0;

		while (getline(infile, line))
		{
			lineCount++;
		}

		infile.close();

		if (lineCount < 45 || lineCount > 45)
		{
			return 2;
		}

		else
		{
			infile.open("items.txt");

			while (getline(infile, line))
			{
				if (lineNum == 1) { 
					prod[prodNum].setID(stoi(line)); 
					lineNum++;
				}
				else if (lineNum == 2) { 
					prod[prodNum].setUnits(stoi(line));
					lineNum++;
				}
				else if (lineNum == 3) { 
					prod[prodNum].setPrices(stod(line)); 
					lineNum++;
				}
				else if (lineNum == 4) { 
					prod[prodNum].setDescription(line);
					lineNum++;
				}
				else 
				{ 
					prod[prodNum].setTaxExempt(stoi(line)); 
					lineNum = 1;
					prodNum++;
				}
			}
		}

		

		infile.close();
	}

	return 1;
}

//****************************************************************
// Definition of calcSales. Accepts units, prices, and sales     *
// arrays as arguments. The size of these arrays is passed       *
// into the num parameter. This function calculates each         *
// product's sales by multiplying its units sold by each unit's  *
// price. The result is stored in the sales array.               *
//****************************************************************

void calcSales(Product prod[])
{
	for (int i = 0; i < NUM_PRODS; i++)
	{
		prod[i].setSales(prod[i].getUnits() * prod[i].getPrices());
	}

}

//***************************************************************
// Definition of function dualSort. Accepts id and sales arrays *
// as arguments. The size of these arrays is passed into size.  *
// This function performs a descending order selection sort on  *
// the sales array. The elements of the id array are exchanged  *
// identically as those of the sales array. size is the number  *
// of elements in each array.                                   *
//***************************************************************

void dualSort(Product prod[])
{
	int startScan, maxIndex, tempid;
	double maxValue;

	for (startScan = 0; startScan < (NUM_PRODS - 1); startScan++)
	{
		maxIndex = startScan;
		maxValue = prod[startScan].getSales();
		tempid = prod[startScan].getID();
		for (int index = startScan + 1; index < NUM_PRODS; index++)
		{
			if (prod[index].getSales() > maxValue)
			{
				maxValue = prod[index].getSales();
				tempid = prod[index].getID();
				maxIndex = index;
			}
		}
		prod[maxIndex].setSales(prod[startScan].getSales());
		prod[maxIndex].setID(prod[startScan].getID());
		prod[startScan].setSales(maxValue);
		prod[startScan].setID(tempid);
	}
}

//****************************************************************
// Definition of showOrder function. Accepts sales and id arrays *
// as arguments. The size of these arrays is passed into num.    *
// The function first displays a heading, then the sorted list   *
// of product numbers and sales.                                 *
//****************************************************************

void showOrder(Product prod[])
{
	cout << "Product Number\tSales\n";
	cout << "----------------------------------\n";
	for (int index = 0; index < NUM_PRODS; index++)
	{
		cout << prod[index].getID() << "\t\t$";
		cout << setw(8) << prod[index].getSales() << endl;
	}
	cout << endl;
}

//*****************************************************************
// Definition of showTotals function. Accepts sales and id arrays *
// as arguments. The size of these arrays is passed into num.     *
// The function first calculates the total units (of all          *
// products) sold and the total sales. It then displays these     *
// amounts.                                                       *
//*****************************************************************

void showTotals(Product prod[])
{
	int totalUnits = 0;
	double totalSales = 0.0;

	for (int index = 0; index < NUM_PRODS; index++)
	{
		totalUnits += prod[index].getUnits();
		totalSales += prod[index].getSales();
	}
	cout << "Total units Sold:  " << totalUnits << endl;
	cout << "Total sales:      $" << totalSales << endl;
}