#include "BoardGame.h"
#include <iostream>
using namespace std;

void BoardGame::Play() {
	cout << "Roll the dice." << endl;
}

void BoardGame::Winner() {
	cout << "Dancing time." << endl;
}