#include "VideoGame.h"
#include <iostream>
using namespace std;

void VideoGame::Play() {
	cout << "Mash the buttons." << endl;
}

void VideoGame::Winner() {
	cout << "Winner music." << endl;
}