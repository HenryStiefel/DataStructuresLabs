#ifndef VIDEOGAME_H
#define VIDEOGAME_H
#include "Game.h"

class VideoGame : public Game
{
private:
	int myDifficulty;

public:
	VideoGame() : Game()
	{
		myDifficulty = 1;
	}

	void setDifficulty(int difficulty) { myDifficulty = difficulty; }
	int getDifficulty() const { return myDifficulty; }

	void Winner();
	void Play();
};
#endif